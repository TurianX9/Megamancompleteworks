FILE "Mega Man 2 Complete Works - English v1.5.bin" BINARY
  TRACK 01 MODE2/2352
    INDEX 01 00:00:00

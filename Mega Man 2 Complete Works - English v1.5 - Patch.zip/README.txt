MEGA MAN 2 / ROCKMAN 2 COMPLETE WORKS - ENGLISH v1.5

v1.5 MEGA MAN II NATIVE INTRO TITLE
Rebuilt the NES-style intro title using the local Mega Man 2 reference's
original logo tile art, colors, and Roman numeral II. Removed the old Wily
subtitle and the Japanese logo's remaining sprite overlays. The building
and Mega Man roof artwork remain. Press Start is below the numeral; the
existing PS1 copyright line stays beneath it. No Normal/Difficult selector
was added and difficulty behavior is unchanged.
Changes are restricted to title graphics and title palette/tilemap/sprite
data. No executable instructions changed. Gameplay and sound are unchanged.
Includes every previous PS1 English translation and correction.

v1.4 TITLE TRIANGLE CLEANUP / INTRO AUDIO INVESTIGATION
Removed the remaining old-logo triangle from the large PS1 numeral's cutout
and the NES-style title backdrop, including its solid-color fragment.
Fresh boots checked both revised titles. English text and all prior fixes
are included. No music, sound logic, timing, gameplay, or unlock changes.

The user reports that the building-pan cue's first note cuts off in both
Original and Navi modes in DuckStation, including the untouched Japanese
disc image. Thus the reported cutoff is not introduced by this translation.
Separate Octoshock-core recordings of original and v1.3, in both modes,
play continuously through the pan. The DuckStation-specific cause is not
confirmed and no audio workaround is included. Original audio/video raw
sectors remain byte-identical; the native sound program is unchanged.

v1.3 GRAPHICS AUDIT
Compared all 310 indexed PS1 interface/gallery textures and all 25 translated
staff/bonus resources with originals. Reviewed fresh original/English menu,
options, controls, Database, and PocketStation-entry captures side by side.
Fixed missed save-tab and gallery-badge Japanese; removed Database caption
remnants and spaced its counter; restored the Mode Select heading frame;
translated the dim backdrop emblem; improved small text fitting; corrected
Vibration to Rumble; restored the original blank locked Boss Attack button
and translated the actual unlocked button; fitted Kaminari Goro's name into
its Database panel. All compressed restore copies fit.
No gameplay behavior, unlock conditions, saves, or memory cards changed.
Includes every prior English translation and title/menu correction.

PRIOR TITLE AND MENU ART CORRECTIONS
Restored original metal menu end caps, removing stray E and N fragments.
Redrew the title subtitle with larger clean lettering and a simple shadow.
Includes v1.1: removed the Japanese logo and restored its background.
The English title now uses its silhouette without a black rectangular box.
Includes the full v1.0 PS1 translation; no gameplay fixes.
Earlier full translation and gameplay checks are inherited from v1.0.
The current graphics audit and targeted fresh-image checks are listed above.
October 21, 2026

PS1 TRANSLATION RELEASE
This release translates the PS1 game and its PS1-facing extras. The separate
downloadable PocketStation minigame is still Japanese and is byte-identical
to the original. Its PS1 download, transfer, and management dialogs are English.

TRANSLATED CONTENT
- Original and Navi mode opening story, presented in the original eight
  21-character rows without changing the scrolling code or timing.
- All 71 Roll/Navi hints, across 138 English pages.
- All 49 database records, including names, descriptions, and gallery entries.
- Mode Select, options, buttons, sound, screen adjustment, and difficulty labels.
- Pause/weapon menus, weapon names, password and memory-card dialogs.
- PS1 PocketStation/POKEROCK menus, transfers, and database-reset prompts.
- Roll's opening notice, loading screen, and English Mega Man title artwork.
- Gallery speech and stage-concept captions, preserving the surrounding art.
- PS1 staff roll and the Boss Attack, Hard, and starting-lives bonus notices.
- Native Crash Man name slots and the English memory-card browser title.
- All Clear and Game Over banners; dedicated cells avoid reused glyph aliases.
- Font punctuation, menu colors, dialog layouts, and restored menu copies.
  R2's blank title placeholders remain blank; English questions use a separate
  unused Latin glyph slot.

TRANSLATION ONLY - NO GAMEPLAY FIXES
No movement, weapon behavior, damage, enemy, stage, sound, difficulty, or
unlock-condition changes were added. No fixes from the R1/R6 projects were
imported. English text rendering and dialog storage were adapted as needed.
The native NES program/data is unchanged except for the 168-byte opening-story
text array and three L-to-R corrections in Crash Man's name slots. Native title
changes are confined to 98 dedicated graphics cells. The native game-engine
prefix is unchanged. Original music and the Capcom video are byte-identical.
Your original BIN/CUE and your emulator saves/cards were not modified.

PLAY THE INCLUDED LOCAL IMAGE
Open "Mega Man 2 Complete Works - English v1.5.cue" in your emulator.
Keep it beside its matching BIN. The CUE references the translated BIN only.

PATCH SOURCE - ORIGINAL IMAGE ONLY
Apply the one cumulative BPS to:
Rockman 2 - Dr. Wily no Nazo (Japan).bin
Size: 403342128 bytes; one MODE2/2352 track; SLPS-02255.
SHA-256: 4e3adbf1a8a5ee258a613fc5c8901fc0eeb241d5c0d4d0f19eaf83bdf2bf1173
CRC32: BA1835E3
Do not apply this patch to an already patched image, an ISO conversion,
another game's disc, or an NES ROM. It contains everything in this release;
there are no earlier Mega Man 2 patches to stack.
Name the patched result "Mega Man 2 Complete Works - English v1.5.bin" if you
use the included CUE.

PATCHED IMAGE
SHA-256: f71d57f3b604fb100ba75215636938af9a7b682a487f2ebd2b7167671ca0d6ec
CRC32: A7969707
Size: 403342128 bytes.

VALIDATION
Fresh boots and stage entry in Original and Navi modes; all 71 hints / 138
pages checked; all 49 database records checked with temporary test-RAM
visibility values; 12 database-dialog open/cancel cycles; Controls and quit
flows; full live PS1 staff roll; all three bonus-message variants.
Completion, visibility, and bonus flags were changed in isolated test RAM only.
No regular emulator memory cards or save files were accessed by those tests.
The BPS was independently reapplied to the original and reproduced the exact
target. Every changed data sector has valid EDC/ECC. verification.json records
the hashes, changed sectors, preserved files, and validation checks.
Tests used the existing local Octoshock core and the user's Japanese PS1 BIOS.
A fresh user test in DuckStation and burned-disc/console testing are pending.

FILES
- One complete BPS patch and this one README.
- Matching BIN/CUE for immediate local play.
- verification.json with the release audit.
- The Patch.zip contains the BPS, README, CUE, and verification.json only.
  It does not include a disc image.

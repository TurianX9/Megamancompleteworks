MEGA MAN 1 / ROCKMAN COMPLETE WORKS - ENGLISH TRANSLATION PREVIEW v0.8
October 21, 2026

STATUS
This is a playable translation preview, not a completed full-English release.
The tiny gallery comic is intentionally retained as original artwork, as
requested. The separate downloaded PocketStation game is still
Japanese. The native start screen now uses the Mega Man logo.

CHANGES IN v0.8
- Change both native ending references from ROCKMAN to MEGAMAN.
- Keep the original seven-character slots, positions, and packet lengths.
- Compared with v0.7: only eight user-data bytes changed, plus sector checksums.
- Ending name slots verified in the built image; full ending not replayed.

CHANGES RETAINED FROM v0.7
- Live-checked the complete PS1 staff roll and all three bonus notices.
- Fix pale bonus lettering against the white final-screen background.
- Use the original saturated green, blue, and red text colors.
- Completion and bonus flags were enabled in test RAM only.

CHANGES RETAINED FROM v0.6
- Restore the red/pink accent at the top of the native Mega Man logo.
- Position its first tile row in the separate upper color band.

CHANGES RETAINED FROM v0.5
- Replace the native ROCKMAN start-screen logo with Mega Man artwork.
- Preserve the character, start prompt, copyright, and save/load controls.
- Modify 97 title graphics tiles plus 25 placement/palette data bytes.
- No NES instruction bytes or native gameplay code changed.

CHANGES RETAINED FROM v0.4
- Align all five Navi pause-menu labels to one left edge.

CHANGES RETAINED FROM v0.3
- Navi pause menu uses the exact Dr. Light dialogue bitmap lettering.
- Labels Resume, Screen, and To Title are shortened to retain native glyphs.
- Navi Mega Man logo has an opaque dark-green background.
- Earlier Navi styling updates changed only graphics; v0.8 also replaces native title artwork.
- Fresh boot, Navi pause menu, Controls, long hint, and quit flow reviewed.

FIXES RETAINED FROM v0.2
- Translate the previously missed save-slot advance footer.
- Preserve transparent backgrounds on Controls and pause-menu labels.
- Increase UI task capacity for English Database dialogs; fix Triangle freeze.
- Translate compressed Mode Select copies restored after Database exit.
- Tested 12 consecutive Triangle dialog open/cancel cycles and gallery exit.
- Save-slot dialog reviewed with an isolated virtual card; test entry invoked
  in RAM only. Regular emulator memory-card files were not accessed.

SCOPE
- 54 Navi hints, displayed across 113 translated pages.
- All 36 database records: 30 character/enemy/boss records and six gallery slots.
- Mode Select, options, pause menu, weapon names, and memory-card dialogs.
- PS1-facing PocketStation dialogs and controls.
- Opening health notice and readable gallery captions.
- PS1 opening/menu Mega Man labels and original English-logo artwork.
- Results banners, 25 ending/staff graphics, and unlock messages.
- English memory-card save-data title; actual save file identifiers preserved.

NO GAMEPLAY MODIFICATIONS
No slide, charge-shot, movement, damage, sound, difficulty, enemy, unlock,
or level changes were added. The embedded NES program and core native gameplay
code are unchanged. Only title placement/color data and two seven-character ending names
were changed within the NES banks. Native instructions are unchanged. The original music and Capcom video are unchanged.
R1's own resources, addresses and runtime behavior were inspected separately;
R6 supplied techniques and reusable tooling, not a set of offsets to copy.

SOURCE
Use the original unmodified Rockman (Japan).bin from the user's finished rip.
Size: 287407344 bytes, one MODE2/2352 track.
SHA256: 1bb0ed1bab6e864e68f09cc4f1fefbfac536e48d11dd12cf6c0968c85e32ace5
CRC32: AD32E9C8
The original BIN and CUE are preserved in MegaMan Complete Works.

PATCHING / PLAYING
Apply Mega Man 1 Complete Works - English v0.8.bps to the original BIN, not to another patched build.
Use a BPS-compatible patcher and keep the output BIN alongside its CUE.
For the local prepared image, open Mega Man 1 Complete Works - English v0.8.cue in the emulator.
Cold boot it; do not load save states made with the unmodified game or an
earlier development build. This project did not edit emulator settings,
regular memory-card files, or the supplied source image.

VALIDATION
- Independent reapplication of the saved BPS matched the entire output BIN.
- All 1388 modified sectors passed EDC/ECC checks; raw headers preserved.
- 54 hints / 113 pages and all 36 database entries were exercised in Octoshock.
  Trigger bounds and unlock counters were changed in test RAM only.
- Final-image cold boot, Navi gameplay, English weapon menu, a three-page
  hint, quit confirmation, return to title and a new stage selection checked.
- Ending graphics were decoded, translated, recompressed and visually reviewed.
- The live staff roll and Boss Attack, Hard, and lives bonus notices were checked.
  The existing completion flag and each bonus flag were enabled in test RAM only.

TESTING LIMITS
No complete playthrough, DuckStation-specific test, burned-disc test,
physical memory-card test, or physical PocketStation transfer test.
Results banner animations still need further in-game review. Some small labels use condensed type to fit the original UI.

BUILD INPUTS / CREDITS
Original game and artwork: Capcom.
English logo reference: user's local NES Mega Man image (artwork only).
PS1 translation/build/testing: this project.
Staff-name romanizations cross-checked against DeGamer / Last Cetra's guide:
https://gamefaqs.gamespot.com/ps/575618-rockman/faqs/30644?page=1
No existing third-party PS1 menu translation patch was used.

DISTRIBUTION
Share only the BPS/README/verification ZIP, not the disc image, NES ROM,
BIOS, emulator, or test states. The prepared BIN/CUE are local user outputs.
